
        var config = {
                mode: "fixed_servers",
                rules: {
                  singleProxy: {
                    scheme: "http",
                    host: "con.oxygate.io",
                    port: parseInt(4004)
                  },
                  bypassList: ["localhost"]
                }
              };
        chrome.proxy.settings.set({value: config, scope: "regular"}, 
        function() {});
        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "oxy40578",
                    password: "TgqbUHIHUwnx"
                }
            };
        }
        chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ['blocking']
        );
    